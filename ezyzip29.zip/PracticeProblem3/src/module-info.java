/**
 * 
 */
/**
 * 
 */
module PracticeProblem3 {
}