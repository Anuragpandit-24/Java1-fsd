package catch2;


import java.util.*;

public class try1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        System.out.println("Enter two integers for division:");

        try {
            // Get user input for two integers
            System.out.print("Enter numerator: ");
            int numerator = scanner.nextInt();

            System.out.print("Enter denominator: ");
            int denominator = scanner.nextInt();

            // Perform division and handle possible ArithmeticException
            int result = numerator / denominator;
            System.out.println("Result: " + result);

        } catch (ArithmeticException e) {
            // Catch and handle ArithmeticException
            System.out.println("Error: Division by zero is not allowed.");

        } catch (Exception e) {
            // Catch and handle other exceptions
            System.out.println("An error occurred: " + e.getMessage());

        } finally {
            // The code in the 'finally' block is executed regardless of whether an exception occurs or not
            System.out.println("Finally block is executed.");
            
            // Close the scanner to avoid resource leaks
            scanner.close();
        }

        System.out.println("Program continues after exception handling.");
        

	}

}
