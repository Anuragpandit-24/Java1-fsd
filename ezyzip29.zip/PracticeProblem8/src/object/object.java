package object;

class Car {
    // Fields (Attributes)
    String make;
    String model;
    int year;

    // Constructor
    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    // Method to display information about the car
    public void displayInfo() {
        System.out.println("Car Information:");
        System.out.println("Make: " + make);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
    }
}

// Another class demonstrating inheritance
class ElectricCar extends Car {
    // Additional field
    int batteryCapacity;

    // Constructor for ElectricCar
    public ElectricCar(String make, String model, int year, int batteryCapacity) {
        super(make, model, year); // Call the constructor of the superclass (Car)
        this.batteryCapacity = batteryCapacity;
    }

    // Overriding the displayInfo method to include battery capacity
    @Override
    public void displayInfo() {
        super.displayInfo(); // Call the displayInfo method of the superclass
        System.out.println("Battery Capacity: " + batteryCapacity + " kWh");
    }
}

public class object {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Car myCar = new Car("Toyota", "Camry", 2022);

        // Use the object to call the displayInfo method
        myCar.displayInfo();

        System.out.println(); // Add a newline for better readability

        // Create an object of the ElectricCar class (which is a subclass of Car)
        ElectricCar myElectricCar = new ElectricCar("Tesla", "Model S", 2023, 100);

        // Use the object to call the displayInfo method (which is overridden in ElectricCar)
        myElectricCar.displayInfo();
		

	}

}
