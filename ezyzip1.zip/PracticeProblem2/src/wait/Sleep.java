package wait;

class SharedResource {
    synchronized void printNumbers() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(Thread.currentThread().getName() + ": " + i);

            try {
                // Introducing a delay using sleep
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    synchronized void printLetters() {
        for (char ch = 'A'; ch <= 'E'; ch++) {
            System.out.println(Thread.currentThread().getName() + ": " + ch);

            try {
                // Introducing a delay using wait
                wait(1000); // Wait for 1 second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
public class Sleep {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final SharedResource sharedResource = new SharedResource();

        // Create a thread to print numbers
        Thread t1 = new Thread(() -> sharedResource.printNumbers());
        t1.setName("Thread-Numbers");

        // Create a thread to print letters
        Thread t2 = new Thread(() -> sharedResource.printLetters());
        t2.setName("Thread-Letters");

        // Start both threads
        t1.start();
        t2.start();

	}

}
