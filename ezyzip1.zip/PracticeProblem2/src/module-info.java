/**
 * 
 */
/**
 * 
 */
module PracticeProblem2 {
}