/**
 * 
 */
/**
 * 
 */
module PracticeProblem7 {
}