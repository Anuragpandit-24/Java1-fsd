package doit;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class operation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String filePath = "example.txt";

        // Create and write to a file
        createFile(filePath, "Hello, this is a sample content.");

        // Read from a file
        readFile(filePath);

        // Update the file
        updateFile(filePath, "Updated content.");

        // Read again to see the updated content
        readFile(filePath);

        // Delete the file
        deleteFile(filePath);
    }

    // Create a file and write content to it
    private static void createFile(String filePath, String content) {
        try {
            Path path = Paths.get(filePath);
            Files.write(path, content.getBytes());
            System.out.println("File created successfully.");
        } catch (IOException e) {
            System.err.println("Error creating the file: " + e.getMessage());
        }
    }

    // Read content from a file
    private static void readFile(String filePath) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            System.out.println("File content:");
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }

    // Update content in a file
    private static void updateFile(String filePath, String updatedContent) {
        try {
            Files.write(Paths.get(filePath), updatedContent.getBytes());
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.err.println("Error updating the file: " + e.getMessage());
        }
    }

    // Delete a file
    private static void deleteFile(String filePath) {
        try {
            Files.deleteIfExists(Paths.get(filePath));
            System.out.println("File deleted successfully.");
        } catch (IOException e) {
            System.err.println("Error deleting the file: " + e.getMessage());
        }


	}

}
