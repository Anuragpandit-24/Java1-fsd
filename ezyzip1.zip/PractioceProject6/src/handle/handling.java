package handle;
import java.util.*;

public class handling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();

            // Attempting to divide by the entered number
            int result = 10 / number;

            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Catching ArithmeticException if the user enters 0
            System.out.println("Error: Division by zero is not allowed.");
        } catch (Exception e) {
            // Catching a general exception for any other unexpected errors
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            // This block will be executed regardless of whether an exception occurred or not
            System.out.println("Finally block executed.");
            scanner.close();
        }

	}

}
