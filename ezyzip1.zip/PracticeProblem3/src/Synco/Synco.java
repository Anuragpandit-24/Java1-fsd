package Synco;

class SharedResource {
    private int count = 0;

    // Synchronized method to increment count
    synchronized void increment() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + ": Count = " + (++count));
            try {
                Thread.sleep(100); // Simulate some processing time
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class Synco {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final SharedResource sharedResource = new SharedResource();

        // Create two threads that share the same resource
        Thread t1 = new Thread(() -> sharedResource.increment());
        t1.setName("Thread-1");

        Thread t2 = new Thread(() -> sharedResource.increment());
        t2.setName("Thread-2");

        // Start both threads
        t1.start();
        t2.start();

	}

}
