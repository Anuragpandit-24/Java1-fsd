package oops;

interface Animal {
    static void sound() {
		// TODO Auto-generated method stub
		
	}
}

interface Mammal extends Animal {

	static void sound() {
		// TODO Auto-generated method stub
		
	}
    // Additional mammal-related methods can be added here
}

interface Bird extends Animal {

	static void sound() {
		// TODO Auto-generated method stub
		
	}
    // Additional bird-related methods can be added here
}

// Diamond problem resolved using interfaces
class Bat implements Mammal, Bird {
    public void sound() {
        // Call the specific method using super
        Mammal.sound();
        Bird.sound();
        
        // Implement sound for Bat
        System.out.println("Bat sound");
    }
}

public class oops {
    public static void main(String[] args) {
        Bat bat = new Bat();
        bat.sound();
    }
}
