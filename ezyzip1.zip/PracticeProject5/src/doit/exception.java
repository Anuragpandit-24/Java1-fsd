package doit;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class exception {
	static void methodWithThrows() throws CustomException {
        System.out.println("Inside methodWithThrows");
        throw new CustomException("This is a custom exception thrown by methodWithThrows");
    }

    // Method that throws an exception using 'throw'
    static void methodWithThrow() {
        System.out.println("Inside methodWithThrow");
        throw new RuntimeException("This is an unchecked exception thrown by methodWithThrow");
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
            // Calling a method that throws an exception using 'throws'
            methodWithThrows();
        } catch (CustomException e) {
            System.out.println("Caught custom exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block for methodWithThrows");
        }

        try {
            // Calling a method that throws an exception using 'throw'
            methodWithThrow();
        } catch (RuntimeException e) {
            System.out.println("Caught runtime exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block for methodWithThrow");
        }

        // Using 'finally' block for cleanup operations
        try {
            System.out.println("Inside try block without exceptions");
        } finally {
            System.out.println("Finally block for cleanup");
        }

        System.out.println("Program continues after exception handling.");

	}

}
